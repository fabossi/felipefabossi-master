module.exports = {
  username: {
    in: 'body',
    exists: true
  }
}
